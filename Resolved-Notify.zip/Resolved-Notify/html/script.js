window.addEventListener('message', function(event) {
    if (event.data.action == 'show') {
        let type = event.data.type;
        let message = event.data.message;
        let duration = event.data.duration;
        let sound = event.data.sound || 'notify'; // Default sound is 'notify'

        // Set notification type (color and icon)
        let notificationContainer = document.getElementById('notify-container');
        let notification = document.createElement('div');
        let icon = document.createElement('i'); // Using <i> tag for Font Awesome icons
        let messageText = document.createElement('span');
        let mark = document.createElement('div');

        notification.className = 'notification';
        notification.id = 'notification';

        // Set the icon and mark based on the notification type
        if (type == 'success') {
            icon.className = 'fas fa-check-circle'; // Success icon (checkmark)
            icon.style.color = 'green'; // Success color
            mark.className = 'mark success';
            notification.classList.add('success');
        } else if (type == 'info') {
            icon.className = 'fas fa-info-circle'; // Info icon (information circle)
            icon.style.color = '#1d72b8'; // Info color (blue)
            mark.className = 'mark info';
            notification.classList.add('info');
        } else if (type == 'error') {
            icon.className = 'fas fa-exclamation-triangle'; // Error icon (alert)
            icon.style.color = 'red'; // Error color
            mark.className = 'mark error';
            notification.classList.add('error');
        }

        // Set the message
        messageText.innerText = message;

        // Append the mark, icon, and message to the notification
        notification.appendChild(mark);
        notification.appendChild(icon);
        notification.appendChild(messageText);

        // Add the notification to the container
        notificationContainer.appendChild(notification);

        // Show the notification container
        notificationContainer.style.display = 'block';

        // Play the sound (ensure the sound path is correct)
        playSound(sound);

        // Hide the notification after the specified duration with a fade-out effect
        setTimeout(() => {
            notification.style.animation = 'fadeOut 0.5s forwards'; // Trigger fade-out animation

            // Remove the notification from the container after the fade-out is complete
            setTimeout(() => {
                notificationContainer.removeChild(notification);

                // Hide the container when no notifications are left
                if (notificationContainer.children.length === 0) {
                    notificationContainer.style.display = 'none';
                }
            }, 500); // Wait for the fade-out animation to finish before removing it
        }, duration);
    }
});

function playSound(sound) {
    if (!sound) return;

    // Updated path to the new sound file (sound.mp3)
    let audio = new Audio('/html/' + sound + '.mp3');  // Using dynamic sound name

    // Preload and play the sound
    audio.preload = 'auto';

    // Play sound and catch any error
    audio.play().catch((error) => {
        console.error('Error playing the sound:', error.message); // More detailed error message
    });
}
