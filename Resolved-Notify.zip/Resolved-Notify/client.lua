RegisterNetEvent('customNotify:Send')
AddEventHandler('customNotify:Send', function(type, message, duration)
    -- Always use "notify.mp3" sound for all notifications
    local sound = "notify"  -- Using the same sound for all notifications

    -- Send the notification data to NUI
    SendNUIMessage({
        action = 'show',
        type = type, 
        message = message,
        duration = duration or 3000,  -- Default duration of 3000ms (3 seconds)
        sound = sound
    })
end)

-- Example command to test notifications
RegisterCommand('testnotify', function()
    TriggerEvent('customNotify:Send', 'success', 'This is a success message!', 5000)
    Wait(2000)
    TriggerEvent('customNotify:Send', 'info', 'This is an info message!', 5000)
    Wait(2000)
    TriggerEvent('customNotify:Send', 'error', 'This is an error message!', 5000)
end, false)
