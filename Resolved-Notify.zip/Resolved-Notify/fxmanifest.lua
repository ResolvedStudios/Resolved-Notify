fx_version 'cerulean'
game 'gta5'

author 'Resolved Coding Studios'
description 'Standalone Custom Notification System'
version '1.0'

client_script 'client.lua'
ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
    'html/notify.mp3'
}
